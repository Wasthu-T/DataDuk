<?php

namespace App\Http\Controllers;

use App\Models\statuspenduduk;
use App\Http\Requests\StorestatuspendudukRequest;
use App\Http\Requests\UpdatestatuspendudukRequest;

class StatuspendudukController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorestatuspendudukRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(statuspenduduk $statuspenduduk)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(statuspenduduk $statuspenduduk)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatestatuspendudukRequest $request, statuspenduduk $statuspenduduk)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(statuspenduduk $statuspenduduk)
    {
        //
    }
}
