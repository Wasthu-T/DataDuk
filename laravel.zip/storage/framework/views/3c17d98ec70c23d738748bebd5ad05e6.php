<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/style_adddata.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>

<div class="card shadow-sm">
    <div class="card-body">
        <h3 class="text-center mb-5 mt-2">Update Data Penduduk</h3>
        <form method="post" id="tambahDataForm" action="/dashboard/ubah/<?php echo e($data->nik); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="nik" class="form-label">NIK</label>
                <div class="input-group">
                    <span class="input-group-text">🆔</span>
                    <input minlength="16" maxlength="16" pattern="\d{16}" onkeypress="return /[0-9]/i.test(event.key)" value="<?php echo e($data->nik); ?>" readonly name="nik" type="text" class="form-control" id="nik">
                </div>
                <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- <div class="invalid-feedback">NIK harus diisi.</div> -->
            </div>
            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <div class="input-group">
                    <span class="input-group-text">👤</span>
                    <input onkeydown="return /[a-zA-Z]/i.test(event.key)" value="<?php echo e($data_status->nama); ?>" required name="nama" type="text" class="form-control" id="nama">
                </div>
                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- <div class="invalid-feedback">Nama harus diisi.</div> -->
            </div>
            <div class="mb-3">
                <label for="tmp_lahir" class="form-label">Tempat Lahir</label>
                <div class="input-group">
                    <span class="input-group-text">🏙</span>
                    <input value="<?php echo e($data->tmp_lahir); ?>" readonly name="tmp_lahir" type="text" class="form-control" id="tempatLahir" placeholder="Masukkan Tempat Lahir">
                </div>
                <?php $__errorArgs = ['tmp_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- <div class="invalid-feedback">Tempat Lahir harus diisi.</div> -->
            </div>
            <div class="mb-3">
                <label for="tgl_lahir" class="form-label">Tanggal Lahir</label>
                <div class="input-group">
                    <span class="input-group-text">🎂</span>
                    <input value="<?php echo e($data->tgl_lahir); ?>" readonly name="tgl_lahir" type="date" class="form-control" id="tanggalLahir">
                </div>
                <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- <div class="invalid-feedback">Tanggal Lahir harus diisi.</div> -->
            </div>
            <div class="mb-3">
                <label for="jns_kel" class="form-label">Jenis Kelamin</label>
                <div class="input-group">
                    <span class="input-group-text">🚻</span>
                    <select required name="jns_kel" class="form-control" id="jenisKelamin">
                        <option value="Laki-laki" <?php echo e($data->jns_kel == "Laki-laki" ? 'selected' : ''); ?>>Laki-laki</option>
                        <option value="Perempuan" <?php echo e($data->jns_kel == "Perempuan" ? 'selected' : ''); ?>>Perempuan</option>
                    </select>
                </div>
                <?php $__errorArgs = ['jns_kel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- <div class="invalid-feedback">Jenis Kelamin harus dipilih.</div> -->
            </div>
            <div class="mb-3">
                <label for="gol_d" class="form-label">Golongan Darah</label>
                <div class="input-group">
                    <span class="input-group-text">🩸</span>
                    <select required name="gol_d" class="form-control" id="golonganDarah">
                        <option value="">Pilih Golongan Darah</option>
                        <option value="A" <?php echo e($data->gol_d == "A" ? 'selected' : ''); ?>>A</option>
                        <option value="B" <?php echo e($data->gol_d == "B" ? 'selected' : ''); ?>>B</option>
                        <option value="AB" <?php echo e($data->gol_d == "AB" ? 'selected' : ''); ?>>AB</option>
                        <option value="O" <?php echo e($data->gol_d == "O" ? 'selected' : ''); ?>>O</option>
                    </select>
                </div>
                <?php $__errorArgs = ['gol_d'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <?php
                $location = $data_status->alamat;
                $locationParts = explode(", ", $location);
                ?>
                <label for="provinsi" class="form-label">Provinsi</label>
                <div class="input-group">
                    <span class="input-group-text">🏡</span>
                    <select required name="provinsi" class="form-control" id="provinsi">
                        <?php if($data_status->alamat): ?>
                        <option value="<?php echo e($locationParts[4]); ?>"><?php echo e($locationParts[4]); ?></option>
                        <?php else: ?>
                        <option value="">Pilih Provinsi</option>
                        <?php endif; ?>
                    </select>
                </div>
                <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="kabupaten" class="form-label">Kabupaten</label>
                <div class="input-group">
                    <span class="input-group-text">🏡</span>
                    <select required name="kabupaten" class="form-control" id="kabupaten">
                        <?php if($data_status->alamat): ?>
                        <option value="<?php echo e($locationParts[3]); ?>"><?php echo e($locationParts[3]); ?></option>
                        <?php else: ?>
                        <option value="">Pilih Kabupaten</option>
                        <?php endif; ?>
                    </select>
                </div>
                <?php $__errorArgs = ['kabupaten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="kecamatan" class="form-label">Kecamatan</label>
                <div class="input-group">
                    <span class="input-group-text">🏡</span>
                    <select required name="kecamatan" class="form-control" id="kecamatan">
                        <?php if($data_status->alamat): ?>
                        <option value="<?php echo e($locationParts[2]); ?>"><?php echo e($locationParts[2]); ?></option>
                        <?php else: ?>
                        <option value="">Pilih Kecamatan</option>
                        <?php endif; ?>
                    </select>
                </div>
                <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="desa" class="form-label">Desa</label>
                <div class="input-group">
                    <span class="input-group-text">🏡</span>
                    <select required name="desa" class="form-control" id="desa">
                        <?php if($data_status->alamat): ?>
                        <option value="<?php echo e($locationParts[1]); ?>"><?php echo e($locationParts[1]); ?></option>
                        <?php else: ?>
                        <option value="">Pilih Desa</option>
                        <?php endif; ?>
                    </select>
                </div>
                <?php $__errorArgs = ['desa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="input-group">
                    <span class="input-group-text">🏡</span>
                    <textarea required name="alamat" class="form-control" id="alamat" placeholder="Masukkan Alamat" rows="3"><?php echo e($locationParts[0]); ?></textarea>
                </div>
                <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="agama" class="form-label">Agama</label>
                <div class="input-group">
                    <span class="input-group-text">🛐</span>
                    <select required name="agama" class="form-control" id="agama">
                        <option value="">Pilih Agama</option>
                        <option value="Islam" <?php echo e($data_status->agama == "Islam" ? 'selected' : ''); ?>>Islam</option>
                        <option value="Kristen" <?php echo e($data_status->agama == "Kristen" ? 'selected' : ''); ?>>Kristen</option>
                        <option value="Katolik" <?php echo e($data_status->agama == "Katolik" ? 'selected' : ''); ?>>Katolik</option>
                        <option value="Hindu" <?php echo e($data_status->agama == "Hindu" ? 'selected' : ''); ?>>Hindu</option>
                        <option value="Budha" <?php echo e($data_status->agama == "Budha" ? 'selected' : ''); ?>>Budha</option>
                        <option value="Konghucu" <?php echo e($data_status->agama == "Konghucu" ? 'selected' : ''); ?>>Konghucu</option>
                    </select>
                </div>
                <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- <div class="invalid-feedback">Status Perkawinan harus dipilih.</div> -->
            </div>

            <div class="mb-3">
                <label for="stt_kawin" class="form-label">Status Perkawinan</label>
                <div class="input-group">
                    <span class="input-group-text">💍</span>
                    <select required name="stt_kawin" class="form-control" id="statusPerkawinan">
                        <option value="">Pilih Status Perkawinan</option>
                        <option value="belum kawin" <?php echo e($data_status->stt_kawin == "belum kawin" ? 'selected' : ''); ?>>Belum Kawin</option>
                        <option value="kawin" <?php echo e($data_status->stt_kawin == "kawin" ? 'selected' : ''); ?>>Kawin</option>
                    </select>
                </div>
                <?php $__errorArgs = ['stt_kawin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- <div class="invalid-feedback">Status Perkawinan harus dipilih.</div> -->
            </div>
            <div class="mb-3">
                <label for="pekerjaan" class="form-label">Pekerjaan</label>
                <div class="input-group">
                    <span class="input-group-text">💼</span>
                    <input value="<?php echo e($data_status->pekerjaan); ?>" required name="pekerjaan" type="text" class="form-control" id="pekerjaan" placeholder="Masukkan Pekerjaan">
                </div>
                <?php $__errorArgs = ['pekerjaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- <div class="invalid-feedback">Pekerjaan harus diisi.</div> -->
            </div>
            <div class="mb-3">
                <label for="kwn" class="form-label">Kewarganegaraan</label>
                <div class="input-group">
                    <span class="input-group-text">🌍</span>
                    <select required name="kwn" class="form-control" id="statusKewarganaan">
                        <option value="">Pilih Status Kewarganaan</option>
                        <option value="WNI" <?php echo e($data_status->kwn == "WNI" ? 'selected' : ''); ?>>WNI</option>
                        <option value="WNA" <?php echo e($data_status->kwn == "WNA" ? 'selected' : ''); ?>>WNA</option>
                    </select>
                </div>
                <?php $__errorArgs = ['kwn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- <div class="invalid-feedback">Kewarganegaraan harus diisi.</div> -->
            </div>
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-custom">Update Data</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/alamat.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\App\dataduk\resources\views/admin/dashboard/edit.blade.php ENDPATH**/ ?>